//
//  ViewController.swift
//  wizPandaTestApp
//
//  Created by Geeta Shirsath on 18/06/20.
//  Copyright © 2020 Geeta Shirsath. All rights reserved.
//

import UIKit
import WebKit
class ViewController: UIViewController {
    
    @IBOutlet weak var appWebKit: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        appWebKit.navigationDelegate = self as? WKNavigationDelegate
        appWebKit.uiDelegate = self as? WKUIDelegate
        
        let url = URL(string: "https://youtu.be/CJN1n3fId_A")
        let requestObj = URLRequest(url: url! as URL)
        appWebKit.load(requestObj)
    }


}

